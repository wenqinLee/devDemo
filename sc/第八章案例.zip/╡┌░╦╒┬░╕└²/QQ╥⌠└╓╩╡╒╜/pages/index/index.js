
Page({

  /**
   * 页面的初始数据
   */
  data: {
    swiperImg: [
      "https://y.gtimg.cn/music/photo_new/T003R720x288M000004buTTB1oAfna.jpg?max_age=2592000",
      "https://y.gtimg.cn/music/photo_new/T003R720x288M000002vZryD2w33XK.jpg?max_age=2592000",
      "https://y.gtimg.cn/music/photo_new/T003R720x288M00000265frs2T1k7y.jpg?max_age=2592000",
      "https://y.gtimg.cn/music/photo_new/T003R720x288M0000024gbEt1qFDXA.jpg?max_age=2592000",
      "https://y.gtimg.cn/music/photo_new/T003R720x288M000000jav33371PXY.jpg?max_age=2592000"
    ],

    interval: 3000,
    duration: 1500,
    activeColor: "#ccc",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})