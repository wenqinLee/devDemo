

var r = wx.getRecorderManager();
var temp;

var audio = wx.createInnerAudioContext();

r.onStop(function(res) {
  console.log(res);
  temp = res.tempFilePath;
});

r.onStart(function() {
  console.log("开始");
});

r.onPause(function () {
  console.log("暂停");
});


Page({

  
  data: {
  
  },

  play: function() {
    audio.src = temp;
    audio.autoplay = true;
  },

  start: function() {
    r.start();
  },

  pause: function() {
    r.pause();
  },

  go: function() {
    r.resume();
  },

  stop: function() {
    r.stop();
  },

})