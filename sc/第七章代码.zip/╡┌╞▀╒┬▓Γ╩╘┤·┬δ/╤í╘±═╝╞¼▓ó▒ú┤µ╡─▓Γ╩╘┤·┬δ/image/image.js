
var path = [];  //保存地址的数组

Page({


  data: {
    
  },

//保存图片
  save: function() {
    for(var i=0; i<path.length; i++) {
      wx.saveImageToPhotosAlbum({
        filePath: path[i],
        fail: function(e) {
          if (e.errMsg == "saveImageToPhotosAlbum:fail auth deny") {
            wx.openSetting({
              //里面还可以写一下成功或失败的回调函数
            })
          }
        }
      })
    }
  },


  //选择图片
  select: function() {
    wx.chooseImage({
      success: function(res) {
        path = path.concat(res.tempFilePaths);    //新地址的数组与老地址的数组连接
      },
    })
  },

  set: function() {
    wx.openSetting({
      
    })
  },


 
})