
console.log(THREE);

class Game {
  constructor() {
    this.cubeConfig = {
      cubeColor: 0x0567a2,
      cubeWidth: 4,
      cubeHeight: 2,
      cubeDeep: 4
    };
    this.jumperConfig = {
      jumperColor: 0xe60012,
      jumperWidth: 1,
      jumperHeight: 2,
      jumperDeep: 1
    };
    this.gameConfig = {
      background: 0xffffff, // 背景颜色
      isMobile: false
    };

    // 画布尺寸
    this.canvasSize = {
      width: window.innerWidth,
      height: window.innerHeight
    };

    // 场景
    this.scene = new THREE.Scene();

    // 相机
    this.camera = new THREE.OrthographicCamera(this.canvasSize.width / -80, this.canvasSize.width / 80, this.canvasSize.height / 80, this.canvasSize.height / -80, 0, 5000);

    // 渲染器
    this.renderer = new THREE.WebGLRenderer({
      antialias: true
    });

    // 相机位置
    this.cameraPos = {
      // 摄像机当前的坐标
      current: new THREE.Vector3(0, 0, 0),
      // 摄影机将要移到的坐标
      next: new THREE.Vector3(0, 0, 0)
    };

    this.cubes = []; // 存放方块的数组
    this.cubeDir = {
      nextDir: ''
    };
    this.jumperStatus = {
      isMouseup: false,
      xSpeed: 0,
      ySpeed: 0
    }
    this.failStatus = {
      failType: 1 // 默认为本方块上面
    }
    this.score = 0
  }

  init() {
    // let axesHelper = new THREE.AxesHelper(100)
    // this.scene.add(axesHelper)

    let controls = new THREE.OrbitControls(this.camera);//创建控件对象
    controls.addEventListener('change', () => {
      this.renderer.render(this.scene, this.camera)
    });

    this.checkIsMobile()
    this.setCamera() // 设置摄像机位置
    this.setRenderer() // 设置渲染器参数
    this.setLight() // 设置光照
    this.createCube() // 加一个方块
    this.createCube() // 加一个方块
    this.createJumper() // 加入游戏者jumper
    this.updateCamera()
    this.render()
    this.renderSkybox()

    let mouseEvents = (this.gameConfig.isMobile) ? {
      down: 'touchstart',
      up: 'touchend'
    } : {
        down: 'mousedown',
        up: 'mouseup'
      }

    window.addEventListener('resize', () => {
      this.handleWindowResize()
    })

    window.addEventListener(mouseEvents.down, () => {
      this.handleMousedown()
    })

    window.addEventListener(mouseEvents.up, () => {
      this.handleMouseup()
    })
  }
  checkIsMobile() {
    let n = navigator.userAgent;
    if (n.match(/Android/i) || n.match(/webOS/i) || n.match(/iPhone/i) || n.match(/iPad/i) || n.match(/iPod/i) || n.match(/BlackBerry/i)) {
      this.gameConfig.isMobile = true
    }
  }
  setCamera() {
    this.camera.position.set(500, 500, 500)
    this.camera.lookAt(this.cameraPos.current)
  }
  setRenderer() {
    this.renderer.setSize(this.canvasSize.width, this.canvasSize.height)
    this.renderer.setClearColor(this.gameConfig.background)
    document.body.appendChild(this.renderer.domElement)
  }
  setLight() {
    // 平行光
    let directionalLight = new THREE.DirectionalLight(0xffffff, 2)
    directionalLight.position.set(3, 10, 5)
    this.scene.add(directionalLight)

    // 环境光
    let light = new THREE.AmbientLight(0xffffff, 0.3)
    this.scene.add(light)
  }
  createCube() {
    let texture = THREE.ImageUtils.loadTexture("img/logo.jpg")
    let material = new THREE.MeshLambertMaterial({
      color: this.cubeConfig.cubeColor,
      map: texture
    })
    let geometry = new THREE.CubeGeometry(this.cubeConfig.cubeWidth, this.cubeConfig.cubeHeight, this.cubeConfig.cubeDeep)
    let mesh = new THREE.Mesh(geometry, material)

    if (this.cubes.length) {
      let random = Math.random()
      this.cubeDir.nextDir = random > 0.5 ? 'left' : 'right'
      mesh.position.x = this.cubes[this.cubes.length - 1].position.x
      mesh.position.y = this.cubes[this.cubes.length - 1].position.y
      mesh.position.z = this.cubes[this.cubes.length - 1].position.z
      // 方块在左边
      if (this.cubeDir.nextDir === 'left') {
        // x距离较上一个-4至-10之间
        mesh.position.x = this.cubes[this.cubes.length - 1].position.x - 4 * Math.random() - 6
        // 方块在右边
      } else {
        // z轴距离上一个-4到-10之间
        mesh.position.z = this.cubes[this.cubes.length - 1].position.z - 4 * Math.random() - 6
      }
    }
    this.cubes.push(mesh)
    this.scene.add(mesh)

    // 每新增一个方块，要更改相机看向的点
    if (this.cubes.length > 1) {
      this.updateCameraPos()
    }
  }
  createJumper() {
    let material = new THREE.MeshLambertMaterial({
      color: this.jumperConfig.jumperColor
    })
    let geometry = new THREE.CubeGeometry(this.jumperConfig.jumperWidth, this.jumperConfig.jumperHeight, this.jumperConfig.jumperDeep)
    // 将几何体向上移动1，因为方块的高度为2
    geometry.translate(0, 1, 0)
    let mesh = new THREE.Mesh(geometry, material)
    // 将网格模型的y轴位置设置在1的地方
    mesh.position.y = 1
    this.jumper = mesh
    this.scene.add(this.jumper)
  }
  // 添加方块的时候会执行这个函数，调用里面的方法
  updateCameraPos() {
    let lastIndex = this.cubes.length - 1
    // 倒数第一个
    let lastPoint = {
      x: this.cubes[lastIndex].position.x,
      z: this.cubes[lastIndex].position.z
    }
    // 倒数第二个
    let penultimatePoint = {
      x: this.cubes[lastIndex - 1].position.x,
      z: this.cubes[lastIndex - 1].position.z
    }
    // 相机将要移动到的点始终在X轴和Z轴的中间位置
    let lookAtPoint = new THREE.Vector3()
    lookAtPoint.x = (lastPoint.x + penultimatePoint.x) / 2
    lookAtPoint.y = 0
    lookAtPoint.z = (lastPoint.z + penultimatePoint.z) / 2
    this.cameraPos.next = lookAtPoint
  }

  updateCamera() {
    // 当前的相机位置
    let current = {
      x: this.cameraPos.current.x,
      y: this.cameraPos.current.y,
      z: this.cameraPos.current.z
    }
    // 出现一个方块后的相机新位置
    let next = {
      x: this.cameraPos.next.x,
      y: this.cameraPos.next.y,
      z: this.cameraPos.next.z
    }
    // 如果当前相机位置的x轴大于出现新方块后计算出来的x轴，或者当前相机位置的y轴大于出现新方块后计算出来的y轴,说明要减小相机位置的坐标值了
    if (current.x > next.x || current.z > next.z) {
      this.cameraPos.current.x -= 0.1
      this.cameraPos.current.z -= 0.1
      // 新相机位置坐标缩减的临界条件
      if (this.cameraPos.current.x - this.cameraPos.next.x < 0.05) {
        this.cameraPos.current.x = this.cameraPos.next.x
      }
      if (this.cameraPos.current.z - this.cameraPos.next.z < 0.05) {
        this.cameraPos.current.z = this.cameraPos.next.z
      }
      // 改变相机看向的点
      this.camera.lookAt(new THREE.Vector3(current.x, 0, current.z))
      this.render()
      requestAnimationFrame(() => {
        this.updateCamera()
      })
    }
  }
  render() {
    this.renderer.render(this.scene, this.camera)
  }
  handleWindowResize() {
    console.log('resize');
    this.setSize()
    this.camera.left = this.canvasSize.width / -80
    this.camera.right = this.canvasSize.width / 80
    this.camera.top = this.canvasSize.height / 80
    this.camera.bottom = this.canvasSize.height / -80
    // 改变相机位置之后需要执行updateProjectionMatrix函数更新相机位置
    this.camera.updateProjectionMatrix()
    this.renderer.setSize(this.canvasSize.width, this.canvasSize.height)
    this.render()
  }
  // 更改窗口的时候需要重新设置一下窗口的大小
  setSize() {
    this.canvasSize.width = window.innerWidth,
      this.canvasSize.height = window.innerHeight
  }

  handleMousedown() {
    if (this.failStatus.failType !== 1 && this.failStatus.failType !== 2) {
      return false
    }
    if (!this.jumperStatus.isMouseup && this.jumper.scale.y > 0.02) {
      this.jumper.scale.y -= 0.01
      this.jumperStatus.xSpeed += 0.004
      this.jumperStatus.ySpeed += 0.008
      this.render(this.scene, this.camera)
      requestAnimationFrame(() => {
        this.handleMousedown()
      })
    }
  }

  handleMouseup() {
    this.jumperStatus.isMouseup = true
    // 只有当jumper的y轴值大于1的时候，才让它动
    if (this.jumper.position.y >= 1) {
      // jumper根据下一个方块的位置来确定水平运动方向，是向左x轴移动 还是 向右z轴移动
      if (this.cubeDir.nextDir === 'left') {
        this.jumper.position.x -= this.jumperStatus.xSpeed
      } else {
        this.jumper.position.z -= this.jumperStatus.xSpeed
      }
      // 不管向左还是向右，jumper始终在垂直方向上运动
      this.jumper.position.y += this.jumperStatus.ySpeed
      // 在运动过程中，方块慢慢变大
      if (this.jumper.scale.y < 1) {
        this.jumper.scale.y += 0.02
      }
      // // jumper在垂直方向上速度慢慢降下来
      this.jumperStatus.ySpeed -= 0.01
      // console.log('shang');
      // 每一次的变化，渲染器都要重新渲染，才能看到渲染效果
      this.render(this.scene, this.camera)
      requestAnimationFrame(() => {
        this.handleMouseup()
      })
    } else {
      this.jumperStatus.isMouseup = false
      this.jumperStatus.ySpeed = 0
      this.jumperStatus.xSpeed = 0
      this.jumper.position.y = 1

      // 判断是否在外面
      this.checkCubeStatus()
      // 2表示跳到了下一个方块上面
      if (this.failStatus.failType === 2) {
        // 成功
        this.score++;
        this.createCube()
        this.updateCamera()
        if (this.successCallback) {
          this.successCallback(this.score)
        }
      } else if (this.failStatus.failType === 0 || this.failStatus.failType === -1 || this.failStatus.failType === -2) {
        this.handleFail()
      }
    }
  }

  checkCubeStatus() {
    if (this.cubes.length > 1) {
      // jumper所在位置
      let jumper = {
        x: this.jumper.position.x,
        z: this.jumper.position.z
      }
      // jumper所在方块的位置
      let jumperCube = {
        x: this.cubes[this.cubes.length - 2].position.x,
        z: this.cubes[this.cubes.length - 2].position.z
      }
      // jumper所在方块的下一个方块的位置
      let jumperNextCube = {
        x: this.cubes[this.cubes.length - 1].position.x,
        z: this.cubes[this.cubes.length - 1].position.z
      }
      let nearSpace;
      let farSpace;

      if (this.cubeDir.nextDir === 'left') {
        nearSpace = Math.abs(jumper.x - jumperCube.x)
        farSpace = Math.abs(jumper.x - jumperNextCube.x)
      } else {
        nearSpace = Math.abs(jumper.z - jumperCube.z)
        farSpace = Math.abs(jumper.z - jumperNextCube.z)
      }

      let safeSpace = this.jumperConfig.jumperWidth / 2 + this.cubeConfig.cubeWidth / 2
      let failType
      if (nearSpace < safeSpace) {
        failType = nearSpace < this.cubeConfig.cubeWidth / 2 ? 1 : -1
      } else if (farSpace < safeSpace) {
        failType = farSpace < this.cubeConfig.cubeWidth / 2 ? 2 : -2
      } else {
        failType = 0
      }
      this.failStatus.failType = failType
    }
  }
  handleFail() {
    if (this.failedCallback) {
      this.failedCallback()
    }
  }
  restart() {
    this.score = 0
    this.cameraPos = {
      current: new THREE.Vector3(0, 0, 0),
      next: new THREE.Vector3(0, 0, 0)
    }
    // 删除所有方块
    for (let item of this.cubes) {
      this.scene.remove(item)
    }
    this.cubes.length = 0
    // 删除jumper
    this.scene.remove(this.jumper)

    // 显示的分数设为 0
    this.successCallback(this.score)
    this.createCube()
    this.createCube()
    this.createJumper()
    this.updateCamera()
  }
  addSuccessFn(fn) {
    this.successCallback = fn
  }
  // 游戏失败的执行函数, 外部传入
  addFailedFn(fn) {
    this.failedCallback = fn
  }
  renderSkybox() {
    let imagePrefix = "img/"
    let directions = ["posx", "negx", "posy", "negy", "posz", "negz"];
    let imageSuffix = ".jpg";
    let skyGeometry = new THREE.CubeGeometry(100, 100, 100);
    let materialArray = [];
    for (let i = 0; i < 6; i++)
      materialArray.push(new THREE.MeshBasicMaterial({
        map: THREE.ImageUtils.loadTexture(imagePrefix + directions[i] + imageSuffix),
        side: THREE.BackSide
      }));
    let skyMaterial = new THREE.MeshFaceMaterial(materialArray);
    let skyBox = new THREE.Mesh(skyGeometry, skyMaterial);
    this.scene.add(skyBox);
  }
}