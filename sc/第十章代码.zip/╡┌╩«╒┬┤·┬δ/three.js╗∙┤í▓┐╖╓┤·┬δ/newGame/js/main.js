
let cxt = canvas.getContext('2d');
const screenHeight = window.innerHeight;
const screenWidth = window.innerWidth;

const imgSrc = "images/bg.jpg";
const imgWidth = 512;
const imgHeight = 512;

export default class Main {
  constructor() {
    this.img = new Image();
    this.img.src = imgSrc;
    this.top = 0;
    this.loop();
  }

  loop() {
    console.log("hahaha");
    if (this.top >= screenHeight) {
      this.top = 0;
    }
    cxt.drawImage(
      this.img,
      0,
      this.top,
      screenWidth,
      screenHeight
    );

    cxt.drawImage(
      this.img,
      0,
      -screenHeight+this.top,
      screenWidth,
      screenHeight

    );

    this.top +=2;
    window.requestAnimationFrame(this.loop.bind(this));
  }
}


