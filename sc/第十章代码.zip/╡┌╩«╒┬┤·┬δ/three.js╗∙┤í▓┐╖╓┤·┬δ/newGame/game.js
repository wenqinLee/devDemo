import './js/libs/weapp-adapter'
import './js/libs/symbol'

var three = require('./js/three/three.js');

var ctx = canvas.getContext('webgl');

// 创建场景
var scene = new three.Scene();
// 创建透视投影相机
var camera = new three.PerspectiveCamera(55,window.innerWidth/window.innerHeight,0.1,1000);
camera.position.set(50,50,50);
camera.lookAt(scene.position);
// 创建渲染器
var renderer = new three.WebGLRenderer(ctx);
renderer.setClearColor(0xEEEEEE,1.0);
renderer.setSize(window.innerWidth, window.innerHeight);
// 将渲染器渲染出的内容加入画布中去
canvas.appendChild(renderer.domElement);

// 创建几何体
var box = new three.BoxGeometry(5,5,5);
var cube = new three.MeshPhongMaterial({color: 0xff0000});

var gather = new three.Mesh(box, cube);

scene.add(gather);
// 添加光线
var light = new three.AmbientLight(0xadde8c);
scene.add(light);

var temp = 0;
function render() {
  temp += 0.03;
  gather.position.x = 10 + (10*(Math.cos(temp)));
  gather.position.y = 2 + (10*Math.abs(Math.sin(temp)));
  renderer.render(scene, camera);
  requestAnimationFrame(render);
}

render();



